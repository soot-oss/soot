package soot.dex.exampleApp;

public class test1 implements InterfaceClass{
	public  int IntVar = 0;
	public  long LongVar = 342;
	public  byte byteVar = 0x1;
	public  char charVar = 'c';
	public  short shortVar = 2;
	public  boolean BoolVar = true;
	public  Object ObjVar = new Object();
	
	public int field1;
	public Object field2;
	public InterfaceClass field3;
	public int[] field4;
	public test1[] field5;
	

	public void method1() {
		System.out.println("I am method 1");
	}

	@Override
	public void interfaceMethod() {
		
	}
    public static int StaticFun() {
		return 21;
    	
	    }
	    
	public test1() {
		
	}

}
