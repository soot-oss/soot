package soot.dex.exampleApp;

public class setTile {
	private int[][] mTileGrid;
    /**
     * Used to indicate that a particular tile (set with loadTile and referenced
     * by an integer) should be drawn at the given x/y coordinates during the
     * next invalidate/draw cycle.
     * 
     * @param tileindex
     * @param x
     * @param y
     */
    public setTile(int tileindex, int x, int y) {
        mTileGrid[x][y] = tileindex;
    }
}
