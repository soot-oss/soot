package soot.dex.exampleApp;

public class castTest {
	private long aLong;
	
	public castTest() {
		aLong = 16;
		System.out.println(aLong);
	}

	    
}
