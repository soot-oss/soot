package soot.dex.exampleApp;

public class myHandler {
	public void removeMessages(int i) {
		
	}
	public void sendMessageDelayed(String str, long delayMillis) {
		
	}
	public String obtainMessage(int i) {
		return "str";
	}
}
