package soot.dex.exampleApp;

public interface InterfaceClass {
	public void interfaceMethod();
}
