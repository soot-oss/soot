package soot.dex.exampleApp;

public class floatConst {
	public floatConst() {
		floatConst1();
	}
	public void floatConst1() {
		//final float floatConstant = 21345.23f;
		final double doubleConstant = 21345.23d;
		
		//System.out.println(floatConstant);
		System.out.println(doubleConstant);
	}
}
