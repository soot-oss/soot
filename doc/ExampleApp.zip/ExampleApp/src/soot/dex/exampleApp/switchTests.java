package soot.dex.exampleApp;

public class switchTests {
	public switchTests() {
		switchTest1(1);
		switchTest2(1);
	}
    public int switchTest1(int x) {
        switch (x) {
            case 1: {
                return 2;
            }
            case 2: {
                return 3;
            }
            case 3: {
                return 4;
            }
            case 4: {
                return 5;
            }
        }
        System.out.println("packed-switch called");
        return 6;
    }

    public int switchTest2(int x) {
        switch (x) {
            case 1: {
                return 2;
            }
            case 10: {
                return 3;
            }
            case 100: {
                return 4;
            }
            case 1000: {
                return 50;
            }
        }
        System.out.println("sparse-switch called");
        return 6;
    }
}
