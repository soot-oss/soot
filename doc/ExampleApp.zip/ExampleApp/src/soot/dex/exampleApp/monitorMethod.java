package soot.dex.exampleApp;

import android.app.Activity;

public class monitorMethod extends Activity {
	public monitorMethod() {
		synchMethod();
	}
    public synchronized void synchMethod() {
    	System.out.println("Synch Method has Monitor-Enter and Monitor-Exit");
    }
}
