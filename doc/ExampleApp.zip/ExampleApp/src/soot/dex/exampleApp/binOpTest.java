package soot.dex.exampleApp;

public class binOpTest {
	public binOpTest() {
		long longVar = 123l;
		int a = 12;
		
		long result = longVar * a;
		System.out.println(result);
	}
}
