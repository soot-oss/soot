package soot.dex.exampleApp;

public class nestedClass {
	private RefreshHandler mRedrawHandler = new RefreshHandler();
	   
    class RefreshHandler extends myHandler {

        public void sleep(long delayMillis) {
        	this.removeMessages(0);
            sendMessageDelayed(obtainMessage(0), delayMillis);
        }
    };
}


