package soot.dex.exampleApp;

public class objectAssign {
	public objectAssign() {
		Object var;
		int a = 1;
		if(a == 1)
			var = 1;
		else
			var = "String";
		System.out.println(var);
	}
}
