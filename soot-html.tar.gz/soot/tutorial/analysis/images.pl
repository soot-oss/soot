# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/{displaymath}mbox{OUT}(s)=mbox{IN}(s)cupmbox{gen}(s)capmbox{prsv}(s){displaymath};MSF=1.6;AAT/;
$cached_env_img{$key} = q|1#1|; 

1;

