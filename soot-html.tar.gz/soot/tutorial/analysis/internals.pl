# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/simpleAnalysisWrapper/;
$ref_files{$key} = "$dir".q|analysis.html|; 
$noresave{$key} = "$nosave";

$key = q/simpleAnalysis/;
$ref_files{$key} = "$dir".q|analysis.html|; 
$noresave{$key} = "$nosave";

1;

