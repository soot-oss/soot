class foo {
  public void sum(int[] a) {
	int total = 0;
	int i=0;
	int b = a[0];

	for (i=0; i<a.length; i++) {
	  total += a[i];
	}
	int c = a[i];
  }
}
