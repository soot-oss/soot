	/*
 * Created on Dec 21, 2004
 *
 */

/**
 * @author jlhotak
 */
public class CommonSubExp {

	public static void main(String[] args) {
		
		int x = 3;
		int y = 9;
		int b = 9;
		int c = 4;
		
		if (x < y){
			x = b + c;
		}
		else {
			y = b + c;
		}
		int z = b + c;
	}
	
	
}
