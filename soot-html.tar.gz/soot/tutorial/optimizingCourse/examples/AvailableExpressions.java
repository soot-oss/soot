/*
 * Created on Dec 30, 2004
 */

/**
 * @author jlhotak
 */
public class AvailableExpressions {

	public static void main(String[] args) {
		int a = 0; int b = 0; int c = 0;
		int d = 0; int u = 0; int v = 0;
		int x = 0; int y = 0;
		
		u = a + b;
		v = c + d;
		while (x < 100){
			x = b + c;
			y = c + d; 
		}
		c = 3;
		
	}
}
