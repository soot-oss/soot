# LaTeX2HTML 2008 (1.71)
# Associate internals original text with physical files.


$key = q/FIG:LATTICE/;
$ref_files{$key} = "$dir".q|sideeffect.html|; 
$noresave{$key} = "$nosave";

$key = q/FIG:SEFORMAT/;
$ref_files{$key} = "$dir".q|sideeffect.html|; 
$noresave{$key} = "$nosave";

$key = q/FIG:SEEXAMPLE/;
$ref_files{$key} = "$dir".q|sideeffect.html|; 
$noresave{$key} = "$nosave";

1;

