# LaTeX2HTML 2008 (1.71)
# Associate images original text with physical files.


$key = q/{figure}center{tikzpicture{node(otffs)at(0,0){otf-fs};node(otffb)at(-1,-1){otf-fffs){};draw[->](aotfs)--(otffs){};tikzpicture{center{{par{{{{figure};FSF=1.6;AAT/;
$cached_env_img{$key} = q|1#1|; 

1;

