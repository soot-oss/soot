public class Item {
	Object data;
}
