package dk.brics.soot.intermediate.foonalasys;

import dk.brics.soot.intermediate.representation.Method;
import soot.util.dot.DotGraph;

public class FooCallgraphCreator {

	public FooCallgraphCreator(Method[] methods) {
		// TODO Auto-generated constructor stub
	}

	public DotGraph getCallGraphAsDot() {
		return null;
	}

}
