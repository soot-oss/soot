#!/usr/local/bin/bash

tar -zcf sootsurvivorsguideexamples.tar.gz `find examples/ -name "*.java"`




