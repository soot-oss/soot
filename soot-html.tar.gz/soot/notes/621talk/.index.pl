#
# WebMagick Run Status File -- PERL Format
#

#
# Directory-global definitions
#

# subdirectory names
@dirNames = (
);

# subdirectory titles
%dirTitles = (
);

# image titles
%imageLabels = (
);

# montage parameters
$montageParameters = 'background=>\'#CCCCCC\',
 borderwidth=>\'0\',
 compose=>\'Replace\',
 font=>\'fixed\',
 foreground=>\'black\',
 geometry=>\'106x80+2+2>\',
 gravity=>\'Center\',
 tile=>\'6x4\',
 transparent=>\'#CCCCCC\'
 bordercolor=>\'black\',
 mapnetscape=>\'0\',
 mattecolor=>\'#CCCCCC\',
 label=>\'%f\n%wx%h\n%b\',
 labelwidth=>\'13\',
 zoomfilter=>\'mitchell\'';

# HTML options
$htmlParams = 'address=>\'\',
 anonymous=>\'0\',
 coloralink=>\'#FF0000\',
 colorback=>\'#CCCCCC\',
 colorfore=>\'#000000\',
 colorlink=>\'#0000EE\',
 colorvlink=>\'#551A8B\',
 dateText=>\'Page updated on February 17, 2000\',
 dircoloralink=>\'#FF0000\',
 dircolorback=>\'#B2B2B2\',
 dircolorfore=>\'#000000\',
 dircolorlink=>\'#0000EE\',
 dircolorvlink=>\'#551A8B\',
 dirindexname=>\'.dirindex\',
 footer=>\'\',
 frameborder=>\'YES\',
 framebordersize=>\'3\',
 framemarginheight=>\'1\',
 framemarginwidth=>\'1\',
 framestyle=>\'1\',
 header=>\'\',
 htmlext=>\'.html\',
 imgindexname=>\'.imgindex\',
 indexname=>\'index.html\',
 jsdirindex=>\'indexjs.html\',
 jsfunctions=>\'../webmagick/icons/webmagick.js\',
 jspageindex=>\'.indexjs.html\',
 jsvariables=>\'.index.js\',
 metaauthor=>\'\',
 metaclassification=>\'\',
 metadescription=>\'\',
 metaexpires=>\'\',
 metakeywords=>\'WebMagick\',
 numpages=>\'1\',
 pageindexname=>\'.index\',
 readme=>\'README.html\',
 readmepresent=>\'0\',
 readmevisible=>\'0\',
 subdirectories=>\'\',
 title=>\'Index of directory "621talk"\',
 version=>\'1.45\'';

# icon URLs
%iconImageUrls = (
	'help' => '../webmagick/icons/blue_readme.gif',
	'next' => '../webmagick/icons/blue_next.gif',
	'next_gray' => '../webmagick/icons/gray_next.gif',
	'prev' => '../webmagick/icons/blue_prev.gif',
	'prev_gray' => '../webmagick/icons/gray_prev.gif',
	'up' => '../webmagick/icons/blue_up.gif',
);

# icon sizes
%iconImageSizes = (
	'help' => 'HEIGHT=24 WIDTH=24',
	'next' => 'HEIGHT=24 WIDTH=24',
	'next_gray' => 'HEIGHT=24 WIDTH=24',
	'prev' => 'HEIGHT=24 WIDTH=24',
	'prev_gray' => 'HEIGHT=24 WIDTH=24',
	'up' => 'HEIGHT=24 WIDTH=24',
);

#
# Page-specific variables
#

# image names ($imageNames[page number][image number])
@imageNames = (
    [
	'Slide00_Outline.jpg',
	'Slide01_Hierarchy.jpg',
	'Slide02_FlowSet.jpg',
	'Slide03_FlowSetReqd.jpg',
	'Slide04_FlowSetOpts.jpg',
	'Slide05_CreateUnitGraph.jpg',
	'Slide06_UsingFA.jpg',
	'Slide07_SimpleLiveLocalsAnalysis1.jpg',
	'Slide08_CachingFA.jpg',
	'Slide09_SimpleLiveLocalsAnalysis2.jpg',
	'Slide10_Boxes.jpg',
	'Slide11_PackagingFA.jpg',
	'Slide12_SimpleLiveLocals.jpg',
	'Slide13_ExtendingFromOutside.jpg',
	'Slide14_PackAdjuster.jpg',
	'Slide15_StmtPrinter.excerpts.jpg',
	'Slide16_CustomExtensionOverview.jpg',
	'Slide17_BodyTransformers.jpg',
	'Slide18_AvailableExpressionsAnnotator.jpg',
	'Slide19_AvailableExample.jpg',
	'Slide20_AvailableExpressions.jpg',
	'Slide21_Chains.jpg',
	'Slide22_Chain.jpg',
    ],
    [
	'Slide18_AvailableExpressionsAnnotator.jpg',
	'Slide19_AvailableExample.jpg',
	'Slide20_AvailableExpressions.jpg',
	'Slide21_Chains.jpg',
	'Slide22_Chain.jpg',
	'StmtPrinter.excerpts.ps',
    ],
);

# thumbnail coordinates ($imageThumbCoords[page number][thumb number])
@imageThumbCoords = (
    [
	'0,0,109,131',
	'110,0,219,131',
	'220,0,329,131',
	'330,0,439,131',
	'440,0,549,131',
	'550,0,659,131',
	'0,132,109,263',
	'110,132,219,263',
	'220,132,329,263',
	'330,132,439,263',
	'440,132,549,263',
	'550,132,659,263',
	'0,264,109,395',
	'110,264,219,395',
	'220,264,329,395',
	'330,264,439,395',
	'440,264,549,395',
	'550,264,659,395',
	'0,396,109,527',
	'110,396,219,527',
	'220,396,329,527',
	'330,396,439,527',
	'440,396,549,527',
    ],
    [
	'0,0,109,131',
	'110,0,219,131',
	'220,0,329,131',
	'330,0,439,131',
	'440,0,549,131',
	'550,0,659,131',
    ],
);

# montage image names ($montageImages[page number])
@montageImages = (
	'.index1.jpg',
	'.index2.jpg',
);

# montage image sizes ($montageImageSizes[page number])
@montageImageSizes = (
	'HEIGHT=536 WIDTH=660',
	'HEIGHT=134 WIDTH=660',
);

$perlVarsLoaded = 1;
