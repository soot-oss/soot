/* Soot - a J*va Optimization Framework
 * Copyright (C) 2000 Patrick Lam
 *
 * Licensed under LGPL. */

package plam;
import soot.*;
import soot.toolkits.scalar.*;
import soot.toolkits.graph.*;
import soot.jimple.*;
import java.util.*;
import soot.util.*;

public class AvailableExpressions
{
    Map unitToExprsAfter;
    Map unitToExprsBefore;

    /** Wrapper for AvailableExpressionsAnalysis. */ 
    public AvailableExpressions(Body b)
    {
        AvailableExpressionsAnalysis analysis = 
            new AvailableExpressionsAnalysis(new CompleteUnitGraph(b));

        // Build unitToExprs map
        {
            unitToExprsAfter = new HashMap(b.getUnits().size() * 2 + 1, 0.7f);
            unitToExprsBefore = new HashMap(b.getUnits().size() * 2 + 1, 0.7f);

            Iterator unitIt = b.getUnits().iterator();

            while(unitIt.hasNext())
            {
                Unit s = (Unit) unitIt.next();
 
                FlowSet set = (FlowSet) analysis.getFlowBefore(s);
                unitToExprsBefore.put(s, 
                                Collections.unmodifiableList(set.toList()));
                
                set = (FlowSet) analysis.getFlowAfter(s);
                unitToExprsAfter.put(s, 
                                Collections.unmodifiableList(set.toList()));
            }  
        }
    }

    public List getAvailableExpressionsBefore(Unit u)
    {
        return (List)unitToExprsBefore.get(u);
    }


    public List getAvailableExpressionsAfter(Unit u)
    {
        return (List)unitToExprsAfter.get(u);
    }
}
