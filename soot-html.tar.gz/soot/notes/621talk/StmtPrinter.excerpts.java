package soot.jimple;

public class StmtPrinter
{
    /** Prints the given JimpleBody to the specified PrintWriter. */
    static void printStatementsInBody(JimpleBody body, java.io.PrintWriter out,
                                      boolean isPrecise, boolean isNumbered)
    {
>        Map unitToExprsBefore = AvailableExpressionsAnnotator.v()
             .getAvailableExprsBeforeFor(body);
>        Map unitToExprsAfter = AvailableExpressionsAnnotator.v()
             .getAvailableExprsAfterFor(body);

        Chain units = body.getUnits();

[omitted code]

                     if(stmtToName.containsKey(currentStmt))
			 out.println("     " + stmtToName.get(currentStmt) + 
                                     ":");
                }
                
                // Temporary hack.
                ArrayList a = new ArrayList();
                a.addAll((List)unitToExprsBefore.get(currentStmt));
                out.println("     // IN: " + a);
		if(isPrecise)
                    out.print(currentStmt.toString(stmtToName, indent));
                else
                    out.print(currentStmt.toBriefString(stmtToName, indent));

                out.print(";"); 
                out.println();

                a = new ArrayList();
                a.addAll((List)unitToExprsAfter.get(currentStmt));
                out.println("     // OUT: "+a);
        }
