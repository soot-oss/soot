//
// WebMagick Run Status File -- JavaScript Format
//
//
// Directory-global definitions
//


// subdirectory names
var dirNames = new Array(
);

// subdirectory titles
var dirTitles = new Object();

// subdirectory links
var dirLinks = new Object();
dirLinks[".."] = 'index.html';

// image titles
var imageLabels = new Object();

// HTML options
var htmlOpts = new Object();
htmlOpts["address"] = '';
htmlOpts["anonymous"] = 0;
htmlOpts["coloralink"] = '#FF0000';
htmlOpts["colorback"] = '#CCCCCC';
htmlOpts["colorfore"] = '#000000';
htmlOpts["colorlink"] = '#0000EE';
htmlOpts["colorvlink"] = '#551A8B';
htmlOpts["dateText"] = 'Page updated on February 17, 2000';
htmlOpts["dircoloralink"] = '#FF0000';
htmlOpts["dircolorback"] = '#B2B2B2';
htmlOpts["dircolorfore"] = '#000000';
htmlOpts["dircolorlink"] = '#0000EE';
htmlOpts["dircolorvlink"] = '#551A8B';
htmlOpts["dirindexname"] = '.dirindex';
htmlOpts["footer"] = '';
htmlOpts["frameborder"] = 'YES';
htmlOpts["framebordersize"] = 3;
htmlOpts["framemarginheight"] = 1;
htmlOpts["framemarginwidth"] = 1;
htmlOpts["framestyle"] = 1;
htmlOpts["header"] = '';
htmlOpts["htmlext"] = '.html';
htmlOpts["imgindexname"] = '.imgindex';
htmlOpts["indexname"] = 'index.html';
htmlOpts["jsdirindex"] = 'indexjs.html';
htmlOpts["jsfunctions"] = '../webmagick/icons/webmagick.js';
htmlOpts["jspageindex"] = '.indexjs.html';
htmlOpts["jsvariables"] = '.index.js';
htmlOpts["metaauthor"] = '';
htmlOpts["metaclassification"] = '';
htmlOpts["metadescription"] = '';
htmlOpts["metaexpires"] = '';
htmlOpts["metakeywords"] = 'WebMagick';
htmlOpts["numpages"] = 1;
htmlOpts["pageindexname"] = '.index';
htmlOpts["readme"] = 'README.html';
htmlOpts["readmepresent"] = 0;
htmlOpts["readmevisible"] = 0;
htmlOpts["subdirectories"] = '';
htmlOpts["title"] = 'Index of directory "621talk"';
htmlOpts["version"] = '1.45';

// icon URLs
var iconImageUrls = new Object();
iconImageUrls["help"] = '../webmagick/icons/blue_readme.gif';
iconImageUrls["next"] = '../webmagick/icons/blue_next.gif';
iconImageUrls["next_gray"] = '../webmagick/icons/gray_next.gif';
iconImageUrls["prev"] = '../webmagick/icons/blue_prev.gif';
iconImageUrls["prev_gray"] = '../webmagick/icons/gray_prev.gif';
iconImageUrls["up"] = '../webmagick/icons/blue_up.gif';

// icon sizes
var iconImageSizes = new Object();
iconImageSizes["help"] = 'HEIGHT=24 WIDTH=24';
iconImageSizes["next"] = 'HEIGHT=24 WIDTH=24';
iconImageSizes["next_gray"] = 'HEIGHT=24 WIDTH=24';
iconImageSizes["prev"] = 'HEIGHT=24 WIDTH=24';
iconImageSizes["prev_gray"] = 'HEIGHT=24 WIDTH=24';
iconImageSizes["up"] = 'HEIGHT=24 WIDTH=24';

//
// Page-Specific variable definitions
//

// image names (imageNames[page number][image number])
var imageNames = new Array(
	new Array(
		'Slide00_Outline.jpg',
		'Slide01_Hierarchy.jpg',
		'Slide02_FlowSet.jpg',
		'Slide03_FlowSetReqd.jpg',
		'Slide04_FlowSetOpts.jpg',
		'Slide05_CreateUnitGraph.jpg',
		'Slide06_UsingFA.jpg',
		'Slide07_SimpleLiveLocalsAnalysis1.jpg',
		'Slide08_CachingFA.jpg',
		'Slide09_SimpleLiveLocalsAnalysis2.jpg',
		'Slide10_Boxes.jpg',
		'Slide11_PackagingFA.jpg',
		'Slide12_SimpleLiveLocals.jpg',
		'Slide13_ExtendingFromOutside.jpg',
		'Slide14_PackAdjuster.jpg',
		'Slide15_StmtPrinter.excerpts.jpg',
		'Slide16_CustomExtensionOverview.jpg',
		'Slide17_BodyTransformers.jpg',
		'Slide18_AvailableExpressionsAnnotator.jpg',
		'Slide19_AvailableExample.jpg',
		'Slide20_AvailableExpressions.jpg',
		'Slide21_Chains.jpg',
		'Slide22_Chain.jpg'
	),
	new Array(
		'Slide18_AvailableExpressionsAnnotator.jpg',
		'Slide19_AvailableExample.jpg',
		'Slide20_AvailableExpressions.jpg',
		'Slide21_Chains.jpg',
		'Slide22_Chain.jpg',
		'StmtPrinter.excerpts.ps'
	)
);

// thumbnail coordinates (imageThumbCoords[page number])
var imageThumbCoords = new Array(
	new Array(
		'0,0,109,131',
		'110,0,219,131',
		'220,0,329,131',
		'330,0,439,131',
		'440,0,549,131',
		'550,0,659,131',
		'0,132,109,263',
		'110,132,219,263',
		'220,132,329,263',
		'330,132,439,263',
		'440,132,549,263',
		'550,132,659,263',
		'0,264,109,395',
		'110,264,219,395',
		'220,264,329,395',
		'330,264,439,395',
		'440,264,549,395',
		'550,264,659,395',
		'0,396,109,527',
		'110,396,219,527',
		'220,396,329,527',
		'330,396,439,527',
		'440,396,549,527'
	),
	new Array(
		'0,0,109,131',
		'110,0,219,131',
		'220,0,329,131',
		'330,0,439,131',
		'440,0,549,131',
		'550,0,659,131'
	)
);

// montage image names (montageImages[page number])
var montageImages = new Array(
	'.index1.jpg',
	'.index2.jpg'
);

// montage image sizes (montageImageSizes[page number])
var montageImageSizes = new Array(
	'HEIGHT=536 WIDTH=660',
	'HEIGHT=134 WIDTH=660'
);

var jsVarsLoaded = 1;
