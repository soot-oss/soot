/* Soot - a J*va Optimization Framework
 * Copyright (C) 2000 Patrick Lam
 *
 * Licensed under LGPL. */

package plam;
import soot.*;
import soot.toolkits.scalar.*;
import soot.toolkits.graph.*;
import soot.jimple.*;
import java.util.*;
import soot.util.*;

/** Runs an available expressions analysis on a body, stuffing the
 * result into a HashMap.  
 *
 * Not the recommended way to add an analysis;
 * I did it to illustrate the workings of a BodyTransformer.
 * Most BodyTransformers change the Body.
 *
 * StmtPrinter uses this Annotator's Maps to fetch the earlier analysis
 * results.  It could equally well run the analysis itself, and that would
 * be more robust to subsequent changes in the body. */

public class AvailableExpressionsAnnotator extends BodyTransformer
{ 
    private static AvailableExpressionsAnnotator instance = 
        new AvailableExpressionsAnnotator();
    private AvailableExpressionsAnnotator() {}

    public static AvailableExpressionsAnnotator v() { return instance; }
    public String getDeclaredOptions() { return super.getDeclaredOptions(); }

    Map bodyToUnitToExprsBefore = new HashMap();
    Map bodyToUnitToExprsAfter = new HashMap();

    /** Available expressions annotator.  Does not change body. */
    protected void internalTransform(Body b, String phaseName, Map options)
    {
        Options.checkOptions(options, phaseName, getDeclaredOptions());

        AvailableExpressions ae = new AvailableExpressions(b);

        bodyToUnitToExprsAfter.put(b, 
                            Collections.unmodifiableMap(ae.unitToExprsAfter));
        bodyToUnitToExprsBefore.put(b, 
                            Collections.unmodifiableMap(ae.unitToExprsBefore));
    }

    public Map getAvailableExprsAfterFor(Body b)
    {
        return (Map) bodyToUnitToExprsAfter.get(b);
    }
    
    public Map getAvailableExprsBeforeFor(Body b)
    {
        return (Map) bodyToUnitToExprsBefore.get(b);
    }
}
